import torch
import torch.nn as nn   # nn模块
from torch.autograd import Variable
import torch.optim as optim
import torch.nn.functional as F
import torchvision.datasets as dsets
import torchvision.transforms as tranforms
import matplotlib.pyplot as plt
import pylab
import torch.utils.data
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_digits

# 定义一些训练用的超参数
image_size = 28  # 图像的总尺寸28*28
num_classes = 10  # 标签的种类数
num_epochs = 20  # 训练的总猜环周期
batch_size = 64  # 一个批次的大小，64张图片

# 开始获取数据
# 加载MNIST数据，MNIST数据属于torchvision包自带的数据，可以直接调用
# 当想调用自己的图俱数据时，可以用torchvision.datasets.ImageFolder 或torch.utils,data.TensorDataset来加载
train_dataset = dsets.MNIST(root='./data', train=True, transform=tranforms.ToTensor(), download=True)
# root是存放路径，通过train提取训练集，将图像转化为Tensor，这样就可以对图像做预处理；同时，当找不到文件时，自动下载
test_dataset = dsets.MNIST(root='./data', train=False, transform=tranforms.ToTensor())
# 训练数据集的加载器，自动将数据切分为成批，顺序随机打乱
train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)

# 将测试数据分为两部分，一部分作为校验数据，一部分作为测试数据
# 校验数据用于检查模型是否过拟合并调整参数，测试数据检验整个模型的工作
# 首先，定义下标数组indices，它相当于对所有test_dataset中的数据的编码
# 然后，定义下标indices_val表示校验集数据的下标，indices_test表示测试集的下标
indices = range(len(test_dataset))
indices_val = indices[:5000]
indices_test = indices[5000:]
# 根据下标构造两个数据集的SubsetRandomSampler采样器，对下标进行采样
sampler_val = torch.utils.data.sampler.SubsetRandomSampler(indices_val)
sampler_test = torch.utils.data.sampler.SubsetRandomSampler(indices_test)
# 根据两个采样器定义加载器
# 注意将sampler_val和sampler_test分别赋给了validation_loader和test_loader
validation_loader = torch.utils.data.DataLoader(dataset=test_dataset,batch_size=batch_size,shuffle=False,
                                                sampler=sampler_val)
test_loader = torch.utils.data.DataLoader(dataset=test_dataset,batch_size=batch_size,shuffle=False,sampler=sampler_test)
# 随便从数据集中读入一张图片，并完成绘制
idx = 70  # random.randint(1,100)
# dataset支持下标索引，其中提取出来的元素为feature、target格式，即属性和标签。[0]表示索引feature
muteimg = train_dataset[idx][0].numpy()
# 一般的图形包含RGB这个通道，而MNIST数据集的影像都是交度，只有一个通道
# 因此忽略通道，只看一个灰度矩阵
# 用imshow画图，会将交度矩阵自动展现为彩色，不同灰度对应颜色不同，从黄到紫
plt.imshow(muteimg[0, ...])
plt.title("{}:{}".format('image sample', train_dataset[idx][1]))
pylab.show()

# 到这一步，数据获取就已经完成了，接下来开始搭建卷积神经网络

# 定义卷积神经网络： 4和8为指定的卷积层的厚度
depth = [4, 8]
class ConvNet(nn.Module):
    def __init__(self):
# 该函数在创建一个ConvNet对象，即调用语句net = Convnet()时，会被调用
# 首先调用父类相应的构造函数
        super(ConvNet, self).__init__()
# 其次构造ConvNet需要的各个神经模块
        self.conv1 = nn.Conv2d(1, 4, 5, padding=2)
# 定义一个卷积层，输入通道为1，输出通道为4，窗口大小为5，padding为2
        self.pool = nn.MaxPool2d(2, 2) #定义池层，一个窗口为2x2的池化运算
# 第二层卷积，输入通道为depth[0]，输出通道为depth[2],窗口为5
        self.conv2 = nn.Conv2d(depth[0], depth[1], 5, padding=2)
# 一个线性连接层，输入尺寸为最后一层立方体的线性平铺，输出层512个节点
        self.fc1 = nn.Linear(image_size//4*image_size//4*depth[1], 512)
        self.fc2 = nn.Linear(512, num_classes) # 最后一层线性分类单元，输入512，输出为要做分类的类别数
    def forward(self,x):
        x = self.conv1(x)  # 第一层卷积
        x = F.relu(x)  # 激活函数用relu，防止过拟合
        # x的尺寸：（batch_size,num_filters,image_with,image_height
        x = self.pool(x)  # 第二层池化，将图片变小
        x = self.conv2(x)  # 第三层又是卷积，窗口为5，输入输出通道分别为depth[0] = 4,depth[1]=8
        x = F.relu(x)  # 非线性函数
        x = self.pool(x)  # 第四层池化，将图片缩小到原来的1/4

        # view函数可以将一个tensor按指定的方式重新排布
        x = x.view(-1,image_size//4*image_size//4*depth[1])
        x = F.relu(self.fc1(x)) #第五层为全连接层，Relu激活函数
        x = F.dropout(x,training=self.training)  # 以默认的0.5概率对这一层进行dropout操作，防止过拟合
        x = self.fc2(x)  # 全连接
        # 输出层为log_Softmax，可以在后面损失函数使用交叉熵计算
        x = F.log_softmax(x,dim=1)
        return x

    def retrieve_features(self,x):
        feature_map1 = F.relu(self.conv1(x))  #完成第一层卷积
        x = self.pool(feature_map1)      # 完成第一层池化
        # 该函数用于提前卷积神经网络的特征图，返回feature_map1,feature_map2为前两层卷积层的特征图
        # 第二层卷积，两层特征图都存储到了featu_map1,feature map2中
        feature_map2 = F.relu(self.conv2(x))
        return (feature_map1,feature_map2)
    # 至此卷积神经网络搭建完成
    # 开始训练
net = ConvNet() # 新建一个卷积网络的实例，此时convNet的__init()__函数会被自动调用
criterion =  nn.CrossEntropyLoss()  # Loss 函数的定义，交叉熵
optimizer = optim.SGD(net.parameters(), lr=0.0001, momentum=0.9)  # 定义优化器，普通的梯度下降算法
record = []  # 记录准确率等数值的容器
weights = []  # 每若干步就记录一次卷积核

#开始循环训练
def rightness(output, target):
    preds = output.data.max(dim=1,keepdim=True)[1]
    return preds.eq(target.data.view_as(preds)).cpu().sum(), len(target)

for epoch in range(num_epochs):
    train_rights = []  # 记录训练数据准确率的容器

    # 下面的enumerate起到构造一个枚举器的作用，在对于train_loader做循环选代时，enumerate会自动输出一个数字指示循环
    # 并记录在batch_idx中
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = Variable(data), Variable(target)
        # 将Tensor转化为Variable,data为一批图像，target为一批标签
        net.train()

        output = net(data)  # 神经网络完成一次前馈计算，得到预测输出output
        loss = criterion(output,target)   # 计算误差
        #print('loss:', loss)
        optimizer.zero_grad()  # 清空梯度
        loss.backward()  # 反向传播
        optimizer.step()  # 一步随机梯度下降算法
        right = rightness(output, target) #计算准确率所需数值
        train_rights.append(right)  # 将计算结果装到列表容器中

        if batch_idx % 100 == 0: # 每隔100个batch执行一次打印操作
            net.eval()  # 给网络模型做标记，标志着模型在训练集上训练
            val_rights = []  # 记录校验数据集准确率的容器
            data1 = Variable(data)
            output1 = net(data1)
            # print("classification report of CNN\n", classification_report(target,output1))
            # 开始在校验集上做循环，计算校验集上的准确度
            for (data, target) in validation_loader:
                data, target = Variable(data), Variable(target)
                # 计算准确率所需要的数据，返回正确的数值
                output = net(data)
                right = rightness(output, target)
                val_rights.append(right)
            train_r = (sum([tup[0] for tup in train_rights]), sum([tup[1] for tup in train_rights]))
            val_r = (sum([tup[0] for tup in val_rights]),sum([tup[1] for tup in val_rights]))

            # 打印准确率等数值，其中正确率为本训练周期epoch开始后到目前批的正确率的平均值
            print(val_r)
            print('训练周期:{}[{}/{} ({:.0f}%)]\tLoss:{:.6f}\t 训练正确率：{:.2f}%\t校验正确率：{:.2f}'.format(
                epoch,batch_idx*batch_size,len(train_loader.dataset),
                100.*batch_idx/len(train_loader),loss.data,
                100.*train_r[0].numpy()/train_r[1],
                100.*val_r[0].numpy()/val_r[1])
            )
            record.append((100-100.*train_r[0]/train_r[1], 100-100.*val_r[0]/val_r[1]))
            weights.append([net.conv1.weight.data.clone(), net.conv1.bias.data.clone(),
                            net.conv2.weight.data.clone(), net.conv2.bias.data.clone()])

        # 绘制损失函数的误差曲线
        plt.figure(figsize=(10, 7))
        plt.title('Training loss curve')
        plt.plot(record)
        plt.xlabel('Steps')
        plt.ylabel('Error rate')
        # pylab.show()

















