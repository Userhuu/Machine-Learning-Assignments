import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_digits
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
import os
import gzip

from PIL import Image
import numpy as np
digits = load_digits()
train = digits.data
target = digits.target
x_train,x_test,y_train,y_true = train_test_split(train,target,test_size=0.2,random_state=33)
ss = StandardScaler()
x_train = ss.fit_transform(x_train)
x_test = ss.transform(x_test)
#第一种分类算法，SVC支持向量机分类
svc = SVC(kernel='rbf') #使用支持向量机进行分类，核函数采用径向基核函数
svc.fit(x_train,y_train)
y_predict = svc.predict(x_test)
print("The Accuraracy of SVC is:",svc.score(x_test,y_true))
print("classification report of SVC\n",classification_report(y_true,y_predict,target_names=digits.target_names.astype(str)))
# 第二种分类算法，朴素贝叶斯分类器分类
from sklearn.naive_bayes import BernoulliNB
clf=BernoulliNB()
clf.fit(x_train,y_train)
y_predict = clf.predict(x_test)
print("The Accuraracy of CNN is:",clf.score(x_test,y_true))
print("classification report of CNN\n",classification_report(y_true,y_predict,target_names=digits.target_names.astype(str)))
#第三种分类算法，决策树分类
from sklearn.tree import DecisionTreeClassifier  #分类树
Tree = DecisionTreeClassifier(criterion = 'entropy',random_state = 0)#另外也可以选择gini
Tree.fit(x_train,y_train)
y_predict = Tree.predict(x_test)
print("The Accuraracy of Tree is:",Tree.score(x_test,y_true))
print("classification report of Tree\n",classification_report(y_true,y_predict,target_names=digits.target_names.astype(str)))